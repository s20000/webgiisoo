create database demo;
create role giisoo with password 'demo123';
alter role giisoo with login;
grant all on database demo to giisoo;